	This source has created by Maickonn Richard.
	Any questions, contact-me: senjaxus@gmail.com

	My Github: https://www.github.com/Senjaxus

	AllaKore Remote is a Remote Access software open source written in Delphi XE6 and Delphi 7.


-----------------------------------------------------------------------


First of all, I apologize for my English because it is not my native language. I live in Brazil. :D


-----------------------------------------------------------------------


#All components used are native to Delphi itself.


<strong>There are some observations to be taken before opening the project:</strong>

* You should install the Delphi XE, the DCLSockets component. Simply open the Delphi XE, click "Component" -> "Install Packages". Now click "Add", now go in the "Bin" folder in the installation of Delphi XE (Example: C:\Program Files (x86)\Embarcadero\Studio\14.0\bin) and open the "dclsocketsXXX.bpl" file. The XXX are numbers according to your version of Delphi.
* Indy10 was presenting MANY problems during the development, so I had to make some decisions to complete the project. For the correct operation of the software, we had to use Delphi to write XE6 Client and Delphi 7 to write the Server. Then, the client must be opened in Delphi XE and the Server in Delphi 7.
* The software requires a central server, I recommend host it on a server inside your country, so there is a low latency.
* Like any BETA project, this is subject to bugs that will be corrected over time. I count on the cooperation of all.
* If they can solve any problem, just send the solution that it will be posted.
* The function of the server is to route all data traffic, delivering each packet to the correct user. The server forwards the packets as soon as they are received to gain performance.
* On the Client project, the unit has two Form_Main constant calls "Host" and "Port". In the constant "Host" you must enter the DNS or IP address of your server. In the constant "Port" you should enter the port that was chosen in the constant of the "Server".



<strong>AllaKore Remote has the following functions:</strong>

* Connection ID and Password.
* Remote access with RFB algorithm (Send only what has changed on the screen).
* Data Compression (zLib).
* Sharer files.
* Chat.


